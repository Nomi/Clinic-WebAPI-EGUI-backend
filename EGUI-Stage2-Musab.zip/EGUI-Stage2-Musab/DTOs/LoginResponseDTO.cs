﻿namespace EGUI_Stage2.DTOs
{
    public class LoginResponseDTO
    {
        public string Token { get; set; }

        public string Role { get; set; }
        public string Username { get; set; }
        public string EmailAddress { get; set; }
    }
}
