﻿namespace EGUI_Stage2.Auxiliary
{
    public static class ConfigHelper
    {
        public static int VisitLengthMinutes => 15;
    }
}
