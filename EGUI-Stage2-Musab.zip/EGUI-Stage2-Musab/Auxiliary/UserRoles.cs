﻿namespace EGUI_Stage2.Auxiliary
{
    public static class UserRoles
    {
        public const string admin = "Admin";
        public const string doctor = "Doctor";
        public const string patient = "Patient";
        public const string unverifiedPatient = "UnverifiedPatient";

    }
}
